//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by zDump.rc
//
#define IDR_RT_MANIFEST1                1
#define IDC_MYICON                      2
#define IDD_MAINDLG                     24
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_ZDUMP                       109
#define IDR_MAINFRAME                   120
#define IDD_ABOUTBOX                    121
#define IDD_PROPRT                      122
#define DLG_GENERAL                     140
#define DLG_STYLES                      141
#define DLG_EXSTYLES                    142
#define DLG_MORESTYLES                  143
#define DLG_MOREEXSTYLES                144
#define IDI_ICON                        160
#define IDI_FLOATINGFINDER              161
#define IDI_DOCKEDFINDER                162
#define IDC_FINDER                      181
#define IDC_WINDOWHANDLE                1050
#define IDC_PROPERTIES                  1051
#define IDC_SETPROPRT                   1051
#define IDC_OPTION                      1052
#define ID_ABOUT                        1053
#define IDC_STAYONTOP                   1054
#define IDC_CAPTION                     1060
#define IDC_CLASS                       1061
#define IDC_STYLE                       1062
#define IDC_RECT                        1063
#define IDC_WEB                         1070
#define IDC_THANKS                      1071
#define IDC_STATIC_SEEKER               1072
#define IDC_TABS                        1111
#define IDC_VISIBLE                     1112
#define IDC_DISABLED                    1113
#define IDC_GROUP                       1114
#define IDC_TABSTOP                     1115
#define IDC_ID                          1116
#define IDC_STYLES                      1120
#define IDC_BORDER                      1121
#define IDC_RIGHTLAYOUT                 1122
#define IDC_NOLAYOUTINHERIT             1123
#define IDC_NOACTIVATE                  1124
#define IDC_APPWINDOW                   1125
#define IDC_DLGMODALFRAME               1126
#define IDC_WINEDGE                     1127
#define IDC_TOPMOST                     1128
#define IDC_NOPARENTNOTIFY              1129
#define IDC_TITLEBAR                    1130
#define IDC_RIGHTREADING                1140
#define IDC_SYSTEMMENU                  1141
#define IDC_RIGHTALIGNED                1142
#define IDC_MINBOX                      1143
#define IDC_LEFTSCROLL                  1144
#define IDC_MAXBOX                      1145
#define IDC_CLIPSIBLING                 1146
#define IDC_CLIPCHILDREN                1147
#define IDC_HORSCROLL                   1148
#define IDC_VERSCROLL                   1149
#define IDC_TOOLWINDOW                  1150
#define IDC_CLIENTEDGE                  1151
#define IDC_STATICADGE                  1152
#define IDC_TRANSPARENT                 1153
#define IDC_ACCEPTFILES                 1154
#define IDC_CONTROLPARENT               1155
#define IDC_CONTEXTHELP                 1156
#define IDC_SENDMSG                     1616
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        173
#define _APS_NEXT_COMMAND_VALUE         32825
#define _APS_NEXT_CONTROL_VALUE         1145
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
