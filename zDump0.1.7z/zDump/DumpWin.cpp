/* DumpWin.cpp --

   This file is part of the "zero Dump 0.1".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   zero Dump library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include "zDump.h"
#include "DumpWin.h"

#ifdef _DEBUG
#define DEBUG_NEW
#endif

int  iTitle=0;
char *szTitle=NULL;
char szClassName[64];
char szStyle[64];
char szDimension[128];
DWORD dwStyle;
DWORD dwExtendedStyle;
UINT dwID;
char szProcess[64];
char szHandle[64];

BOOL	m_bCarriageReturn;
DWORD	m_dwIndentLevel;
DWORD	m_dwIndentSize;
DWORD	m_dwDetails;

bool SaveToRegistry(bool StayOnTop);
bool LoadFromRegistry(bool *StayOnTop);

void DumpTitle(HWND hWnd);
void DumpClassName(HWND hWnd);
void DumpStyles(HWND hWnd);
void DumpDimension(HWND hWnd);

void DumpWindow(HWND hWnd);
void GetWindowInfo(HWND hWnd);


//----------------------------------------------------------------------------
bool SaveToRegistry(bool StayOnTop)
{
    char KeyMain[127];
	HKEY RootKey=HKEY_CURRENT_USER;
    strcpy(KeyMain,"Software\\zDump");
    bool Result;
	HKEY hKeyOption;
	DWORD dwDispos;
	if(ERROR_SUCCESS!=::RegCreateKeyEx(RootKey,KeyMain,
									0,NULL,
									REG_OPTION_NON_VOLATILE	
									,KEY_ALL_ACCESS,NULL,
									&hKeyOption,&dwDispos))
	{
		return FALSE;
	}
    __try 
    {
		if(::RegOpenKeyEx(RootKey,KeyMain,0,KEY_ALL_ACCESS,&hKeyOption)== ERROR_SUCCESS) 
        {	
			::RegSetValueEx(hKeyOption,
						"StayOnTop",0,
						REG_DWORD,
						reinterpret_cast<BYTE *>(&StayOnTop),
						4);
			Result=TRUE;
        }
		else Result=FALSE;
    }
	__finally
    {
       ::RegCloseKey(hKeyOption);
    }
    return(Result);
}
//----------------------------------------------------------------------------
bool LoadFromRegistry(bool *StayOnTop)
{
    char KeyMain[127];
	HKEY RootKey=HKEY_CURRENT_USER;
    strcpy(KeyMain,"Software\\zDump");
	HKEY hKeyOption;
	bool Result;
	DWORD dwSize     = 0; 
	DWORD dwDataType = 0; 
	DWORD dwValue    = 0; 
	if(::RegOpenKeyEx(RootKey,KeyMain,0,KEY_ALL_ACCESS,&hKeyOption) != ERROR_SUCCESS) 
	{ 
		return FALSE;
	}
    __try 
	{
		if(::RegOpenKeyEx(RootKey,KeyMain,0,KEY_ALL_ACCESS,&hKeyOption) == ERROR_SUCCESS) 
		{ 

			dwSize = sizeof(StayOnTop); 
			::RegQueryValueEx(hKeyOption,
						"StayOnTop",NULL,
						&dwDataType,
						reinterpret_cast<BYTE *>(StayOnTop),
						&dwSize);
			Result=TRUE;
        }
		else Result=FALSE;
    }
	__finally
    {
		::RegCloseKey(hKeyOption);
    }
    return(Result);
}

//---------------------------------------------------------------------------
void DumpTitle(HWND hWnd)
{
	int iLen;
	GetClassName(hWnd, szClassName, sizeof(szClassName)/sizeof(TCHAR));
	CharUpperBuff(szClassName,(DWORD)strlen(szClassName));
	if((strstr(szClassName,"EDIT")==NULL)&&(strstr(szClassName,"BOX")==NULL))
	{
		iLen = GetWindowTextLength(hWnd);
		szTitle=new TCHAR[iLen+1];
		memset(szTitle,0,iLen+1);
		GetWindowText(hWnd,szTitle,iLen+1);
	}
	else
	{
		iLen=128;
		szTitle=new TCHAR[iLen+1];
		memset(szTitle,0,iLen+1);
		HWND hWndParent=GetParent(hWnd);
		SendDlgItemMessage(hWndParent,dwID,
						   WM_GETTEXT, 
						   iLen+1, (LPARAM)szTitle);
		szTitle[127]=0;
	}
	SetDlgItemText(hwndMain,IDC_CAPTION,szTitle);
}

//---------------------------------------------------------------------------
void DumpClassName(HWND hWnd)
{
	GetClassName(hWnd, szClassName, sizeof(szClassName)/sizeof(TCHAR));
	SetDlgItemText(hwndMain,IDC_CLASS,szClassName);
}

//---------------------------------------------------------------------------
void DumpStyles(HWND hWnd)
{
	_itoa(dwStyle,szStyle,16);
	CharUpperBuff(szStyle,(DWORD)strlen(szStyle));
	SetDlgItemText(hwndMain,IDC_STYLE,szStyle);
}

//---------------------------------------------------------------------------
void DumpDimension(HWND hWnd)
{
	char sztemp[10];
	RECT wndRect;
	GetWindowRect(hWnd,&wndRect);
	strcpy(szDimension,"(");
	_itoa(wndRect.left,sztemp,10);
	strcat(szDimension,sztemp);
	strcat(szDimension," ,");
	_itoa(wndRect.top,sztemp,10);
	strcat(szDimension,sztemp);
	strcat(szDimension,")-(");
	_itoa(wndRect.right,sztemp,10);
	strcat(szDimension,sztemp);
	strcat(szDimension," ,");
	_itoa(wndRect.bottom,sztemp,10);
	strcat(szDimension,sztemp);
	strcat(szDimension,") ");
	_itoa(wndRect.right-wndRect.left,sztemp,10);
	strcat(szDimension,sztemp);
	strcat(szDimension,"x");
	_itoa(wndRect.bottom-wndRect.top,sztemp,10);
	strcat(szDimension,sztemp);
	SetDlgItemText(hwndMain,IDC_RECT,szDimension);
}

//---------------------------------------------------------------------------
void DumpWindow(HWND hWnd)
{
	if (!IsWindow(hWnd)) return;
	//WINDOWINFO wininfo=GetWindowInfo(hWnd,&wininfo);
	dwID = GetWindowLong(hWnd, GWL_ID);
	dwStyle =GetWindowLong(hWnd, GWL_STYLE);
	dwExtendedStyle =GetWindowLong(hWnd, GWL_EXSTYLE);
	DumpTitle(hWnd);
	DumpClassName(hWnd);
	DumpStyles(hWnd);
	DumpDimension(hWnd);
}

//---------------------------------------------------------------------------
void GetWindowInfo(HWND hWnd)
{	
	DumpWindow(hWnd);
}