/* DumpSeek.cpp --

   This file is part of the "zero Dump 0.1".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   zero Dump library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include "zDump.h"
#include "DumpSeek.h"

#ifdef _DEBUG
#define DEBUG_NEW
#endif

void DumpChildWindowLocal(HWND hWnd,POINT point);
void DumpChildWindow(HWND hWnd,POINT point);
void DumpIntoChildWindow(HWND hWnd,POINT point);

HWND hChildFound	= NULL;
LONG dx,dy,_dx,_dy;

//---------------------------------------------------------------------------
void DumpIntoChildWindow(HWND hWnd,POINT point)
{
	if (!IsWindow(hWnd)) return;
	RECT wndRect;
	GetWindowRect(hWnd,&wndRect);
	if((wndRect.left<point.x)&&(point.x<wndRect.right)&&
	   (wndRect.top<point.y)&&(point.y<wndRect.bottom)
	   )
	{
		if((IsWindow(hWnd))&&(hWnd!=NULL))
		{
			dx=wndRect.right-wndRect.left;
			dy=wndRect.bottom-wndRect.top;
			if((_dx>dx)&&(_dy>dy))
			{
				hChildFound=hWnd;
				_dx=dx;
				_dy=dy;
			}
			DumpChildWindowLocal(hWnd,point);
		}
	}
}

//---------------------------------------------------------------------------
void DumpChildWindowLocal(HWND hWnd,POINT point)
{
	// check if there is at least one child
	HWND hChild;
	hChild =GetWindow(hWnd, GW_CHILD);	
	RECT wndRect;
	GetWindowRect(hChild ,&wndRect);
	if (IsWindow(hChild))
	{
		while (IsWindow(hChild))
		{
			GetWindowRect(hChild ,&wndRect);
			if((wndRect.left<point.x)&&(point.x<wndRect.right)&&
			   (wndRect.top<point.y)&&(point.y<wndRect.bottom))
			{
				DumpIntoChildWindow(hChild,point);
			}
			hChild = GetWindow(hChild, GW_HWNDNEXT);
			if(GetParent(hChild)==0)break;
		}
	}
}

//---------------------------------------------------------------------------
void DumpIntoParentWindow(HWND hWnd,POINT point)
{
	if (!IsWindow(hWnd)) return;
	RECT wndRect;
	GetWindowRect(hWnd,&wndRect);
	if((wndRect.left<point.x)&&(point.x<wndRect.right)&&
	   (wndRect.top<point.y)&&(point.y<wndRect.bottom)
	   )
	{
		if((IsWindow(hWnd))&&(hWnd!=NULL))
		{
			dx=wndRect.right-wndRect.left;
			dy=wndRect.bottom-wndRect.top;
			if((_dx>dx)&&(_dy>dy))
			{
				hChildFound=hWnd;
				_dx=dx;
				_dy=dy;
			}
			DumpChildWindowLocal(hWnd,point);
		}
	}
}

//---------------------------------------------------------------------------
void DumpParentWindowLocal(HWND hWnd,POINT point)
{
	HWND hParent;
	// retrieve its parent
	hParent =GetParent(hWnd);
	// check if it and its parent is a window dialog frame
	if(((GetWindowLong(hWnd, GWL_STYLE)&WS_DLGFRAME)==WS_DLGFRAME)&&
	   ((GetWindowLong(hParent, GWL_STYLE)&WS_DLGFRAME)==WS_DLGFRAME))
	{
		return;
	}
	if((IsWindow(hParent))&&(hParent!=NULL))
	{
		DumpChildWindowLocal(hParent,point);
		DumpParentWindowLocal(hParent,point);
	}
}

//---------------------------------------------------------------------------
void SeekDumpWindow(HWND hWnd,POINT point)
{
	_dx=99999;
	_dy=99999;
	DumpChildWindowLocal(hWnd,point);
	DumpParentWindowLocal(hWnd,point);
}
//---------------------------------------------------------------------------
