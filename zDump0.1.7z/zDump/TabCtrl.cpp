/* TabCtrl.cpp : Defines the entry point for the application.

   This file is part of the "zero Dump 0.1".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   zero Dump library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include "zDump.h"
#include "TabCtrl.h"
#include "DumpWin.h"
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <winuser.h>


HWND hHandle;
DWORD BACKdwID;
DWORD BACKdwStyle;
DWORD BACKdwExtendedStyle;
bool DoUpdateCaption=FALSE;
HWND hwndCombo;

char* szStyles[3]={"Overlapped", "Popup", "Child"};
char* szBorders[4]={"None", "Thin", "Resizing", "Dialog Frame"};
//----------------------------------------------
//------------------- General ------------------
bool Visible;	//WS_VISIBLE,//Creates a window that is initially visible.
bool Disabled;	//WS_DISABLED,//Creates a window that is initially disabled. A disabled window cannot receive input from the user. To change this after a window has been created, use EnableWindow. 
bool Group;		//WS_GROUP,//Specifies the first control of a group of controls. The group consists of this first control and all controls defined after it, up to the next control with the WS_GROUP style. The first control in each group usually has the WS_TABSTOP style so that the user can move from group to group. The user can subsequently change the keyboard focus from one control in the group to the next control in the group by using the direction keys.
bool TabStop;	//WS_TABSTOP,//Specifies a control that can receive the keyboard focus when the user presses the TAB key. Pressing the TAB key changes the keyboard focus to the next control with the WS_TABSTOP style. 
//----------------------------------------------
//bool Iconic;	//WS_ICONIC,//Creates a window that is initially minimized. Same as the WS_MINIMIZE style.
//bool Minimize;	//WS_MINIMIZE,//Creates a window that is initially minimized. Same as the WS_ICONIC style.
//bool Maximize;	//WS_MAXIMIZE,//Creates a window that is initially maximized.
//----------------------------------------------
//------------------- Styles -------------------
//&Styles:Overlapped, Popup, Child
bool OverlappedStyle;	//WS_OVERLAPPED,//Creates an overlapped window. An overlapped window has a title bar and a border. Same as the WS_TILED style.
						//WS_OVERLAPPEDWINDOW,//Creates an overlapped window with the WS_OVERLAPPED, WS_CAPTION, WS_SYSMENU, WS_THICKFRAME, WS_MINIMIZEBOX, and WS_MAXIMIZEBOX styles. Same as the WS_TILEDWINDOW style.
						//WS_TILED,//Creates an overlapped window. An overlapped window has a title bar and a border. Same as the WS_OVERLAPPED style. 
bool PopupStyle;		//WS_POPUP,//Creates a pop-up window. This style cannot be used with the WS_CHILD style.
						//WS_POPUPWINDOW,//Creates a pop-up window with WS_BORDER, WS_POPUP, and WS_SYSMENU styles. The WS_CAPTION and WS_POPUPWINDOW styles must be combined to make the window menu visible.
bool ChildStyle;		//WS_CHILD,//Creates a child window. A window with this style cannot have a menu bar. This style cannot be used with the WS_POPUP style.
						//WS_CHILDWINDOW,//Same as the WS_CHILD style.
//----------------------------------------------
//&Border: None, Thin, Resizing, Dialog Frame
bool NoneBorder;
bool ThinBorder;		//WS_BORDER,//Creates a window that has a thin-line border.
bool ResizingBorder;	//WS_SIZEBOX,//Creates a window that has a sizing border. Same as the WS_THICKFRAME style.
						//WS_THICKFRAME,//Creates a window that has a sizing border. Same as the WS_SIZEBOX style.
bool DialogFrameBorder;	//WS_DLGFRAME,//Creates a window that has a border of a style typically used with dialog boxes. A window with this style cannot have a title bar.
//----------------------------------------------
bool TitleBar;		//WS_TILEDWINDOW,//Creates an overlapped window with the WS_OVERLAPPED, WS_CAPTION, WS_SYSMENU, WS_THICKFRAME, WS_MINIMIZEBOX, and WS_MAXIMIZEBOX styles. Same as the WS_OVERLAPPEDWINDOW style. 
					//WS_CAPTION,//Creates a window that has a title bar (includes the WS_BORDER style).
bool SystemMenu;	//WS_SYSMENU,//Creates a window that has a window menu on its title bar. The WS_CAPTION style must also be specified.
bool MinimizeBox;	//WS_MINIMIZEBOX,//Creates a window that has a minimize button. Cannot be combined with the WS_EX_CONTEXTHELP style. The WS_SYSMENU style must also be specified. 
bool MaximizeBox;	//WS_MAXIMIZEBOX,//Creates a window that has a maximize button. Cannot be combined with the WS_EX_CONTEXTHELP style. The WS_SYSMENU style must also be specified. 
bool ClipSiblings;	//WS_CLIPSIBLINGS,//Clips child windows relative to each other; that is, when a particular child window receives a WM_PAINT message, the WS_CLIPSIBLINGS style clips all other overlapping child windows out of the region of the child window to be updated. If WS_CLIPSIBLINGS is not specified and child windows overlap, it is possible, when drawing within the client area of a child window, to draw within the client area of a neighboring child window.
bool ClipChildren;	//WS_CLIPCHILDREN,//Excludes the area occupied by child windows when drawing occurs within the parent window. This style is used when creating the parent window.
bool HorizontalScroll;//WS_HSCROLL,//Creates a window that has a horizontal scroll bar.
bool VerticalScroll;//WS_VSCROLL,//Creates a window that has a vertical scroll bar.

//----------------------------------------------
//----------------- More Styles ----------------

//----------------------------------------------
//--------------- Extended Styles --------------
bool ToolWindow;		//WS_EX_TOOLWINDOW,//Creates a tool window; that is, a window intended to be used as a floating toolbar. A tool window has a title bar that is shorter than a normal title bar, and the window title is drawn using a smaller font. A tool window does not appear in the taskbar or in the dialog that appears when the user presses ALT+TAB. If a tool window has a system menu, its icon is not displayed on the title bar. However, you can display the system menu by right-clicking or by typing ALT+SPACE. 
bool ClientEdge;		//WS_EX_CLIENTEDGE,//Specifies that a window has a border with a sunken edge.
bool StaticEdge;		//WS_EX_STATICEDGE,//Creates a window with a three-dimensional border style intended to be used for items that do not accept user input.
bool Transparent;		//WS_EX_TRANSPARENT,//Specifies that a window created with this style should not be painted until siblings beneath the window (that were created by the same thread) have been painted. The window appears transparent because the bits of underlying sibling windows have already been painted.
bool AcceptFiles;		//WS_EX_ACCEPTFILES,//Specifies that a window created with this style accepts drag-drop files.
bool ControlParent;		//WS_EX_CONTROLPARENT,//The window itself contains child windows that should take part in dialog box navigation. If this style is specified, the dialog manager recurses into children of this window when performing navigation operations such as handling the TAB key, an arrow key, or a keyboard mnemonic.
bool ContextHelp;		//WS_EX_CONTEXTHELP,//Includes a question mark in the title bar of the window. When the user clicks the question mark, the cursor changes to a question mark with a pointer. If the user then clicks a child window, the child receives a WM_HELP message. The child window should pass the message to the parent window procedure, which should call the WinHelp function using the HELP_WM_HELP command. The Help application displays a pop-up window that typically contains help for the child window.
bool NoParentNotify;	//WS_EX_NOPARENTNOTIFY,//Specifies that a child window created with this style does not send the WM_PARENTNOTIFY message to its parent window when it is created or destroyed.
bool RightReadingOrder;	//WS_EX_RTLREADING,//If the shell language is Hebrew, Arabic, or another language that supports reading-order alignment, the window text is displayed using right-to-left reading-order properties. For other languages, the style is ignored.
						//WS_EX_LTRREADING,//The window text is displayed using left-to-right reading-order properties. This is the default.
bool RightAligned;		//WS_EX_RIGHT,//The window has generic "right-aligned" properties. This depends on the window class. This style has an effect only if the shell language is Hebrew, Arabic, or another language that supports reading-order alignment; otherwise, the style is ignored.
						//WS_EX_LEFT,//Creates a window that has generic left-aligned properties. This is the default.
bool LeftScrollBar;		//WS_EX_LEFTSCROLLBAR,//If the shell language is Hebrew, Arabic, or another language that supports reading order alignment, the vertical scroll bar (if present) is to the left of the client area. For other languages, the style is ignored.
						//WS_EX_RIGHTSCROLLBAR,//Vertical scroll bar (if present) is to the right of the client area. This is the default.
//----------------------------------------------
//------------- More Extended Styles -----------
bool RightLayout;		//WS_EX_LAYOUTRTL,//Arabic and Hebrew versions of Windows 98/Me, Windows 2000/XP: Creates a window whose horizontal origin is on the right edge. Increasing horizontal values advance to the left. 
bool NoLayoutInherit;	//WS_EX_NOINHERITLAYOUT,//Windows 2000/XP: A window created with this style does not pass its window layout to its child windows.
bool NoActivate;		//WS_EX_NOACTIVATE,//Windows 2000/XP: A top-level window created with this style does not become the foreground window when the user clicks it. The system does not bring this window to the foreground when the user minimizes or closes the foreground window. 
bool AppWindow;			//WS_EX_APPWINDOW,//Forces a top-level window onto the taskbar when the window is visible. 
bool DialogModalFrame;	//WS_EX_DLGMODALFRAME,//Creates a window that has a double border; the window can, optionally, be created with a title bar by specifying the WS_CAPTION style in the dwStyle parameter.
bool WindowEdge;		//WS_EX_WINDOWEDGE,//Specifies that a window has a border with a raised edge.
bool TopMost;			//WS_EX_TOPMOST,//Specifies that a window created with this style should be placed above all non-topmost windows and should stay above them, even when the window is deactivated. To add or remove this style, use the SetWindowPos function.
//----------------------------------------------
//bool Composited;//WS_EX_COMPOSITED,//Windows XP: Paints all descendants of a window in bottom-to-top painting order using double-buffering. For more information, see Remarks. This cannot be used if the window has a class style of either CS_OWNDC or CS_CLASSDC. 
//bool Layered;//WS_EX_LAYERED,//Windows 2000/XP: Creates a layered window. Note that this cannot be used for child windows. Also, this cannot be used if the window has a class style of either CS_OWNDC or CS_CLASSDC. 
//bool MDIChild;//WS_EX_MDICHILD,//Creates a multiple-document interface (MDI) child window.
//bool OverlappedWindow;//WS_EX_OVERLAPPEDWINDOW,//Combines the WS_EX_CLIENTEDGE and WS_EX_WINDOWEDGE styles.
//bool PaletteWindow;//WS_EX_PALETTEWINDOW,//Combines the WS_EX_WINDOWEDGE, WS_EX_TOOLWINDOW, and WS_EX_TOPMOST styles.
/*
//----------------------------------------------
//------------------- General ------------------
//Vi&sible
WS_VISIBLE,//Creates a window that is initially visible.
//Dis&abled
WS_DISABLED,//Creates a window that is initially disabled. A disabled window cannot receive input from the user. To change this after a window has been created, use EnableWindow. 
//&Group
WS_GROUP,//Specifies the first control of a group of controls. The group consists of this first control and all controls defined after it, up to the next control with the WS_GROUP style. The first control in each group usually has the WS_TABSTOP style so that the user can move from group to group. The user can subsequently change the keyboard focus from one control in the group to the next control in the group by using the direction keys.
//Ta&b stop
//WS_TABSTOP,//Specifies a control that can receive the keyboard focus when the user presses the TAB key. Pressing the TAB key changes the keyboard focus to the next control with the WS_TABSTOP style. 
//----------------------------------------------
WS_ICONIC,//Creates a window that is initially minimized. Same as the WS_MINIMIZE style.
WS_MINIMIZE,//Creates a window that is initially minimized. Same as the WS_ICONIC style.
WS_MAXIMIZE,//Creates a window that is initially maximized.
//----------------------------------------------
//------------------- Styles -------------------
//&Styles:Overlapped, Popup, Child
WS_OVERLAPPED,//Creates an overlapped window. An overlapped window has a title bar and a border. Same as the WS_TILED style.
WS_TILED,//Creates an overlapped window. An overlapped window has a title bar and a border. Same as the WS_OVERLAPPED style. 
WS_POPUP,//Creates a pop-up window. This style cannot be used with the WS_CHILD style.
WS_POPUPWINDOW,//Creates a pop-up window with WS_BORDER, WS_POPUP, and WS_SYSMENU styles. The WS_CAPTION and WS_POPUPWINDOW styles must be combined to make the window menu visible.
WS_CHILD,//Creates a child window. A window with this style cannot have a menu bar. This style cannot be used with the WS_POPUP style.
WS_CHILDWINDOW,//Same as the WS_CHILD style.
WS_TILEDWINDOW,//Creates an overlapped window with the WS_OVERLAPPED, WS_CAPTION, WS_SYSMENU, WS_THICKFRAME, WS_MINIMIZEBOX, and WS_MAXIMIZEBOX styles. Same as the WS_OVERLAPPEDWINDOW style. 
WS_OVERLAPPEDWINDOW,//Creates an overlapped window with the WS_OVERLAPPED, WS_CAPTION, WS_SYSMENU, WS_THICKFRAME, WS_MINIMIZEBOX, and WS_MAXIMIZEBOX styles. Same as the WS_TILEDWINDOW style.
//&Border: None, Thin, Resizing, Dialog Frame
WS_BORDER,//Creates a window that has a thin-line border.
WS_SIZEBOX,//Creates a window that has a sizing border. Same as the WS_THICKFRAME style.
WS_DLGFRAME,//Creates a window that has a border of a style typically used with dialog boxes. A window with this style cannot have a title bar.
WS_THICKFRAME,//Creates a window that has a sizing border. Same as the WS_SIZEBOX style.
//T&itle Bar
WS_CAPTION,//Creates a window that has a title bar (includes the WS_BORDER style).
//System men&u
WS_SYSMENU,//Creates a window that has a window menu on its title bar. The WS_CAPTION style must also be specified.
//Mi&nimize box
WS_MINIMIZEBOX,//Creates a window that has a minimize button. Cannot be combined with the WS_EX_CONTEXTHELP style. The WS_SYSMENU style must also be specified. 
//Ma&ximize box
WS_MAXIMIZEBOX,//Creates a window that has a maximize button. Cannot be combined with the WS_EX_CONTEXTHELP style. The WS_SYSMENU style must also be specified. 
//Cli&p siblings
WS_CLIPSIBLINGS,//Clips child windows relative to each other; that is, when a particular child window receives a WM_PAINT message, the WS_CLIPSIBLINGS style clips all other overlapping child windows out of the region of the child window to be updated. If WS_CLIPSIBLINGS is not specified and child windows overlap, it is possible, when drawing within the client area of a child window, to draw within the client area of a neighboring child window.
//Clip &children
WS_CLIPCHILDREN,//Excludes the area occupied by child windows when drawing occurs within the parent window. This style is used when creating the parent window.
//Hori&zontal scroll
WS_HSCROLL,//Creates a window that has a horizontal scroll bar.
//&Vertical scroll
WS_VSCROLL,//Creates a window that has a vertical scroll bar.
//----------------------------------------------
//----------------- More Styles ----------------
//----------------------------------------------
//--------------- Extended Styles --------------
//T&ool window
WS_EX_TOOLWINDOW,//Creates a tool window; that is, a window intended to be used as a floating toolbar. A tool window has a title bar that is shorter than a normal title bar, and the window title is drawn using a smaller font. A tool window does not appear in the taskbar or in the dialog that appears when the user presses ALT+TAB. If a tool window has a system menu, its icon is not displayed on the title bar. However, you can display the system menu by right-clicking or by typing ALT+SPACE. 
//&Client edge
WS_EX_CLIENTEDGE,//Specifies that a window has a border with a sunken edge.
//Static e&dge
WS_EX_STATICEDGE,//Creates a window with a three-dimensional border style intended to be used for items that do not accept user input.
//Trans&parent
WS_EX_TRANSPARENT,//Specifies that a window created with this style should not be painted until siblings beneath the window (that were created by the same thread) have been painted. The window appears transparent because the bits of underlying sibling windows have already been painted.
//&Accept files
WS_EX_ACCEPTFILES,//Specifies that a window created with this style accepts drag-drop files.
//Con&trol parent
WS_EX_CONTROLPARENT,//The window itself contains child windows that should take part in dialog box navigation. If this style is specified, the dialog manager recurses into children of this window when performing navigation operations such as handling the TAB key, an arrow key, or a keyboard mnemonic.
//Conte&xt help
WS_EX_CONTEXTHELP,//Includes a question mark in the title bar of the window. When the user clicks the question mark, the cursor changes to a question mark with a pointer. If the user then clicks a child window, the child receives a WM_HELP message. The child window should pass the message to the parent window procedure, which should call the WinHelp function using the HELP_WM_HELP command. The Help application displays a pop-up window that typically contains help for the child window.
//&No parent notify
WS_EX_NOPARENTNOTIFY,//Specifies that a child window created with this style does not send the WM_PARENTNOTIFY message to its parent window when it is created or destroyed.
//Rig&ht-to-left reading order
WS_EX_RTLREADING,//If the shell language is Hebrew, Arabic, or another language that supports reading-order alignment, the window text is displayed using right-to-left reading-order properties. For other languages, the style is ignored.
WS_EX_LTRREADING,//The window text is displayed using left-to-right reading-order properties. This is the default.
//&Right aligned text
WS_EX_RIGHT,//The window has generic "right-aligned" properties. This depends on the window class. This style has an effect only if the shell language is Hebrew, Arabic, or another language that supports reading-order alignment; otherwise, the style is ignored.
WS_EX_LEFT,//Creates a window that has generic left-aligned properties. This is the default.
//&Left scroll bar
WS_EX_LEFTSCROLLBAR,//If the shell language is Hebrew, Arabic, or another language that supports reading order alignment, the vertical scroll bar (if present) is to the left of the client area. For other languages, the style is ignored.
WS_EX_RIGHTSCROLLBAR,//Vertical scroll bar (if present) is to the right of the client area. This is the default.
//----------------------------------------------
//------------- More Extended Styles -----------
//&Right to left layout
WS_EX_LAYOUTRTL,//Arabic and Hebrew versions of Windows 98/Me, Windows 2000/XP: Creates a window whose horizontal origin is on the right edge. Increasing horizontal values advance to the left. 
//&No layout inheritance
WS_EX_NOINHERITLAYOUT,//Windows 2000/XP: A window created with this style does not pass its window layout to its child windows.
//No &activate
WS_EX_NOACTIVATE,//Windows 2000/XP: A top-level window created with this style does not become the foreground window when the user clicks it. The system does not bring this window to the foreground when the user minimizes or closes the foreground window. 
//Application &window
WS_EX_APPWINDOW,//Forces a top-level window onto the taskbar when the window is visible. 
//Dialog &modal frame
WS_EX_DLGMODALFRAME,//Creates a window that has a double border; the window can, optionally, be created with a title bar by specifying the WS_CAPTION style in the dwStyle parameter.
//Window &edge
WS_EX_WINDOWEDGE,//Specifies that a window has a border with a raised edge.
//&Top most
WS_EX_TOPMOST,//Specifies that a window created with this style should be placed above all non-topmost windows and should stay above them, even when the window is deactivated. To add or remove this style, use the SetWindowPos function.
//----------------------------------------------
WS_EX_COMPOSITED,//Windows XP: Paints all descendants of a window in bottom-to-top painting order using double-buffering. For more information, see Remarks. This cannot be used if the window has a class style of either CS_OWNDC or CS_CLASSDC. 
WS_EX_LAYERED,//Windows 2000/XP: Creates a layered window. Note that this cannot be used for child windows. Also, this cannot be used if the window has a class style of either CS_OWNDC or CS_CLASSDC. 
WS_EX_MDICHILD,//Creates a multiple-document interface (MDI) child window.
WS_EX_OVERLAPPEDWINDOW,//Combines the WS_EX_CLIENTEDGE and WS_EX_WINDOWEDGE styles.
WS_EX_PALETTEWINDOW,//Combines the WS_EX_WINDOWEDGE, WS_EX_TOOLWINDOW, and WS_EX_TOPMOST styles.
*/

HWND WINAPI OnTabbedDialogInit(HWND hwndDlg);
DLGTEMPLATE * WINAPI DoLockDlgRes(LPCSTR lpszResName);
HWND WINAPI OnSelChanged(HWND hwndDlg);
VOID WINAPI OnChildDialogInit(HWND hwndDlg);
LRESULT CALLBACK ChildDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

VOID UpdateFlags(bool bSaveAndValidate)
{
	if(bSaveAndValidate)
	{
		//------------------- General ------------------
		if((dwStyle&WS_VISIBLE)==WS_VISIBLE)	Visible=TRUE;else Visible=FALSE;
		if((dwStyle&WS_DISABLED)==WS_DISABLED)	Disabled=TRUE;else Disabled=FALSE;
		if((dwStyle&WS_GROUP)==WS_GROUP)		Group=TRUE;else Group=FALSE;
		if((dwStyle&WS_TABSTOP)==WS_TABSTOP)	TabStop=TRUE;else TabStop=FALSE;
		//----------------------------------------------
		//------------------- Styles -------------------
		//&Styles:Overlapped, Popup, Child
		if(((dwStyle&WS_POPUP)!=WS_POPUP)&&
		   ((dwStyle&WS_CHILD)!=WS_CHILD))

		{
			OverlappedStyle=TRUE;
		}
		else OverlappedStyle=FALSE;
		if((dwStyle&WS_POPUP)==WS_POPUP)			PopupStyle=TRUE;else PopupStyle=FALSE;
		if((dwStyle&WS_CHILD)==WS_CHILD)			ChildStyle=TRUE;else ChildStyle=FALSE;
		//----------------------------------------------
		//&Border: None, Thin, Resizing, Dialog Frame
		if(((dwStyle&WS_BORDER)!=WS_BORDER)&&	
		((dwStyle&WS_SIZEBOX)!=WS_SIZEBOX)&&
		((dwStyle&WS_DLGFRAME)!=WS_DLGFRAME))
		{
			NoneBorder=TRUE;
		}else NoneBorder=FALSE;
		if((dwStyle&WS_BORDER)==WS_BORDER)		ThinBorder=TRUE;else ThinBorder=FALSE;
		if((dwStyle&WS_SIZEBOX)==WS_SIZEBOX)	ResizingBorder=TRUE;else ResizingBorder=FALSE;
		if((dwStyle&WS_DLGFRAME)==WS_DLGFRAME)	DialogFrameBorder=TRUE;else DialogFrameBorder=FALSE;
		//----------------------------------------------
		if((dwStyle&WS_CAPTION)==WS_CAPTION)		TitleBar=TRUE;else TitleBar=FALSE;
		if((dwStyle&WS_SYSMENU)==WS_SYSMENU)		SystemMenu=TRUE;else SystemMenu=FALSE;
		if((dwStyle&WS_MINIMIZEBOX)==WS_MINIMIZEBOX)MinimizeBox=TRUE;else MinimizeBox=FALSE;
		if((dwStyle&WS_MAXIMIZEBOX)==WS_MAXIMIZEBOX)MaximizeBox=TRUE;else MaximizeBox=FALSE;
		if((dwStyle&WS_CLIPSIBLINGS)==WS_CLIPSIBLINGS)ClipSiblings=TRUE;else ClipSiblings=FALSE;
		if((dwStyle&WS_CLIPCHILDREN)==WS_CLIPCHILDREN)ClipChildren=TRUE;else ClipChildren=FALSE;
		if((dwStyle&WS_HSCROLL)==WS_HSCROLL)		HorizontalScroll=TRUE;else HorizontalScroll=FALSE;
		if((dwStyle&WS_VSCROLL)==WS_VSCROLL)		VerticalScroll=TRUE;else VerticalScroll=FALSE;
		//----------------------------------------------
		//----------------- More Styles ----------------

		//----------------------------------------------
		//--------------- Extended Styles --------------
		if((dwExtendedStyle&WS_EX_TOOLWINDOW)==WS_EX_TOOLWINDOW)ToolWindow=TRUE;else ToolWindow=FALSE;
		if((dwExtendedStyle&WS_EX_CLIENTEDGE)==WS_EX_CLIENTEDGE)ClientEdge=TRUE;else ClientEdge=FALSE;
		if((dwExtendedStyle&WS_EX_STATICEDGE)==WS_EX_STATICEDGE)StaticEdge=TRUE;else StaticEdge=FALSE;
		if((dwExtendedStyle&WS_EX_TRANSPARENT)==WS_EX_TRANSPARENT)Transparent=TRUE;else Transparent=FALSE;
		if((dwExtendedStyle&WS_EX_ACCEPTFILES)==WS_EX_ACCEPTFILES)AcceptFiles=TRUE;else AcceptFiles=FALSE;
		if((dwExtendedStyle&WS_EX_CONTROLPARENT)==WS_EX_CONTROLPARENT)ControlParent=TRUE;else ControlParent=FALSE;
		if((dwExtendedStyle&WS_EX_CONTEXTHELP)==WS_EX_CONTEXTHELP)ContextHelp=TRUE;else ContextHelp=FALSE;
		if((dwExtendedStyle&WS_EX_NOPARENTNOTIFY)==WS_EX_NOPARENTNOTIFY)NoParentNotify=TRUE;else NoParentNotify=FALSE;
		if((dwExtendedStyle&WS_EX_RTLREADING)==WS_EX_RTLREADING)RightReadingOrder=TRUE; else RightReadingOrder=FALSE;
		if((dwExtendedStyle&WS_EX_RIGHT)==WS_EX_RIGHT)RightAligned=TRUE; else RightAligned=FALSE;
		if((dwExtendedStyle&WS_EX_LEFTSCROLLBAR)==WS_EX_LEFTSCROLLBAR)LeftScrollBar=TRUE; else LeftScrollBar=FALSE;
		//----------------------------------------------
		//------------- More Extended Styles -----------
		if((dwExtendedStyle&WS_EX_LAYOUTRTL)==WS_EX_LAYOUTRTL)			RightLayout=TRUE;else RightLayout=FALSE;
		if((dwExtendedStyle&WS_EX_NOINHERITLAYOUT)==WS_EX_NOINHERITLAYOUT)NoLayoutInherit=TRUE;else NoLayoutInherit=FALSE;
		if((dwExtendedStyle&WS_EX_NOACTIVATE)==WS_EX_NOACTIVATE)		NoActivate=TRUE;else NoActivate=FALSE;
		if((dwExtendedStyle&WS_EX_APPWINDOW)==WS_EX_APPWINDOW)			AppWindow=TRUE;else AppWindow=FALSE;
		if((dwExtendedStyle&WS_EX_DLGMODALFRAME)==WS_EX_DLGMODALFRAME)	DialogModalFrame=TRUE;else DialogModalFrame=FALSE;
		if((dwExtendedStyle&WS_EX_WINDOWEDGE)==WS_EX_WINDOWEDGE)		WindowEdge=TRUE;else WindowEdge=FALSE;
		if((dwExtendedStyle&WS_EX_TOPMOST)==WS_EX_TOPMOST)				TopMost=TRUE;else TopMost=FALSE;
		//----------------------------------------------
	}
	else
	{
		//------------------- General ------------------
		if(Visible) dwStyle|=WS_VISIBLE; else dwStyle&=~WS_VISIBLE;
		if(Disabled)dwStyle|=WS_DISABLED; else dwStyle&=~WS_DISABLED;
		if(Group)	dwStyle|=WS_GROUP; else dwStyle&=~WS_GROUP;
		if(TabStop) dwStyle|=WS_TABSTOP; else dwStyle&=~WS_TABSTOP;
		//----------------------------------------------
		//------------------- Styles -------------------
		//&Styles:Overlapped, Popup, Child
		if(OverlappedStyle) 
		{
			dwStyle&=~WS_POPUP;
			dwStyle&=~WS_CHILD;
		}
		if(PopupStyle)		dwStyle|=WS_POPUP; else dwStyle&=~WS_POPUP;
		if(ChildStyle)		dwStyle|=WS_CHILD; else dwStyle&=~WS_CHILD;
		//----------------------------------------------
		//&Border: None, Thin, Resizing, Dialog Frame
		if(NoneBorder) 
		{
			dwStyle&=~WS_BORDER;
			dwStyle&=~WS_SIZEBOX;
			dwStyle&=~WS_DLGFRAME;
		}
		if(ThinBorder)		
		{
			dwStyle|=WS_BORDER;
			dwStyle&=~WS_SIZEBOX;
			dwStyle&=~WS_DLGFRAME;
		}else 
		if(ResizingBorder)
		{
			dwStyle&=~WS_BORDER;
			dwStyle|=WS_SIZEBOX;
			dwStyle&=~WS_DLGFRAME;
		}else
		if(DialogFrameBorder)
		{
			dwStyle&=~WS_BORDER;
			dwStyle&=~WS_SIZEBOX;
			dwStyle|=WS_DLGFRAME;;
		}
		//----------------------------------------------
		if(TitleBar)		dwStyle|=WS_CAPTION; else dwStyle&=~WS_CAPTION;
		if(SystemMenu)		dwStyle|=WS_SYSMENU; else dwStyle&=~WS_SYSMENU;
		if(MinimizeBox)		dwStyle|=WS_MINIMIZEBOX; else dwStyle&=~WS_MINIMIZEBOX;
		if(MaximizeBox)		dwStyle|=WS_MAXIMIZEBOX; else dwStyle&=~WS_MAXIMIZEBOX;
		if(ClipSiblings)	dwStyle|=WS_CLIPSIBLINGS; else dwStyle&=~WS_CLIPSIBLINGS;
		if(ClipChildren)	dwStyle|=WS_CLIPCHILDREN; else dwStyle&=~WS_CLIPCHILDREN;
		if(HorizontalScroll)dwStyle|=WS_HSCROLL; else dwStyle&=~WS_HSCROLL;
		if(VerticalScroll)	dwStyle|=WS_VSCROLL; else dwStyle&=~WS_VSCROLL;
		//----------------------------------------------
		//----------------- More Styles ----------------

		//----------------------------------------------
		//--------------- Extended Styles --------------
		if(ToolWindow)		dwExtendedStyle|=WS_EX_TOOLWINDOW; else dwExtendedStyle&=~WS_EX_TOOLWINDOW;
		if(ClientEdge)		dwExtendedStyle|=WS_EX_CLIENTEDGE; else dwExtendedStyle&=~WS_EX_CLIENTEDGE;
		if(StaticEdge)		dwExtendedStyle|=WS_EX_STATICEDGE; else dwExtendedStyle&=~WS_EX_STATICEDGE;
		if(Transparent)		dwExtendedStyle|=WS_EX_TRANSPARENT; else dwExtendedStyle&=~WS_EX_TRANSPARENT;
		if(AcceptFiles)		dwExtendedStyle|=WS_EX_ACCEPTFILES; else dwExtendedStyle&=~WS_EX_ACCEPTFILES;
		if(ControlParent)	dwExtendedStyle|=WS_EX_CONTROLPARENT; else dwExtendedStyle&=~WS_EX_CONTROLPARENT;
		if(ContextHelp)		dwExtendedStyle|=WS_EX_CONTEXTHELP; else dwExtendedStyle&=~WS_EX_CONTEXTHELP;
		if(NoParentNotify)	dwExtendedStyle|=WS_EX_NOPARENTNOTIFY; else dwExtendedStyle&=~WS_EX_NOPARENTNOTIFY;
		if(RightReadingOrder)dwExtendedStyle|=WS_EX_RTLREADING; else dwExtendedStyle&=~WS_EX_RTLREADING;
		if(RightAligned)	dwExtendedStyle|=WS_EX_RIGHT; else dwExtendedStyle&=~WS_EX_RIGHT;
		if(LeftScrollBar)	dwExtendedStyle|=WS_EX_LEFTSCROLLBAR; else dwExtendedStyle&=~WS_EX_LEFTSCROLLBAR;
		//----------------------------------------------
		//------------- More Extended Styles -----------
		if(RightLayout)		dwExtendedStyle|=WS_EX_LAYOUTRTL; else dwExtendedStyle&=~WS_EX_LAYOUTRTL;
		if(NoLayoutInherit)	dwExtendedStyle|=WS_EX_NOINHERITLAYOUT; else dwExtendedStyle&=~WS_EX_NOINHERITLAYOUT;
		//if(NoActivate)	dwExtendedStyle|=WS_EX_NOACTIVATE; else dwExtendedStyle&=~WS_EX_NOACTIVATE;
		if(AppWindow)		dwExtendedStyle|=WS_EX_APPWINDOW; else dwExtendedStyle&=~WS_EX_APPWINDOW;
		if(DialogModalFrame)dwExtendedStyle|=WS_EX_DLGMODALFRAME; else dwExtendedStyle&=~WS_EX_DLGMODALFRAME;
		if(WindowEdge)		dwExtendedStyle|=WS_EX_WINDOWEDGE; else dwExtendedStyle&=~WS_EX_WINDOWEDGE;
		if(TopMost)			
		{
			dwExtendedStyle|=WS_EX_TOPMOST; 
			SetWindowPos(hHandle, 
						HWND_TOPMOST, 0, 0, 0, 0,
						SWP_NOSIZE|SWP_NOMOVE);
		}
		else
		{
			dwExtendedStyle&=~WS_EX_TOPMOST;
			SetWindowPos(hHandle, 
						HWND_NOTOPMOST, 0, 0, 0, 0,
						SWP_NOSIZE|SWP_NOMOVE);
		}
		//----------------------------------------------
		if(BACKdwID!=dwID)		SetWindowLong(hHandle, GWL_ID, dwID);
		if(BACKdwStyle!=dwStyle)SetWindowLong(hHandle, GWL_STYLE, dwStyle);
		if(BACKdwExtendedStyle=dwExtendedStyle)
								SetWindowLong(hHandle, GWL_EXSTYLE, dwExtendedStyle);
		if(Visible)
		{
			ShowWindow(hHandle,SW_HIDE);
			ShowWindow(hHandle,SW_SHOW);
		}
		else
		{
			ShowWindow(hHandle,SW_SHOW);
			ShowWindow(hHandle,SW_HIDE);
		}
		UpdateWindow(GetParent(hHandle));
		BACKdwID=dwID;
		BACKdwStyle=dwStyle;
		BACKdwExtendedStyle=dwExtendedStyle;
	}
}

#define C_PAGES 5
LPSTR szTabName[C_PAGES]=
{
	"General",
	"Styles",
	"More Styles",
	"Extended Styles",
	"More Extended Styles"
};
 typedef struct tag_dlghdr { 
    HWND hwndTab;       // tab control 
    HWND hwndDisplay;   // current child dialog box 
    RECT rcDisplay;     // display rectangle for the tab control 
    DLGTEMPLATE *apRes[C_PAGES]; 
} DLGHDR; 
DLGHDR *pHdr;

HWND WINAPI OnTabbedDialogInit(HWND hwndDlg) 
{ 
	RECT rcClient; 
    pHdr = (DLGHDR *) LocalAlloc(LPTR, sizeof(DLGHDR)); 
    TCITEM tie; 
    RECT rcTab; 
    int i; 
	// Save a pointer to the DLGHDR strucTRUE. 

    SetWindowLong(hwndDlg, GWL_USERDATA, (LONG) pHdr); 
	
	// Initialize the tab control.
	//InitCommonControls();
	pHdr->hwndTab = GetDlgItem(hwndDlg, IDC_TABS); 
	if (pHdr->hwndTab == NULL)// handle error 
	{
        return NULL;
    }
    // Determine the bounding rectangle for all child dialog boxes. 
	SetRectEmpty(&rcTab);
	GetClientRect(pHdr->hwndTab, &rcTab); 
	GetClientRect(hwndDlg, &rcClient); 
	rcTab.top=rcClient.top+26;
	rcTab.left=10;
	rcTab.right=rcTab.right+2;
	rcTab.bottom=rcTab.top+rcTab.bottom-28;

	// Add a tab for each of the three child dialog boxes.
    tie.mask = TCIF_TEXT | TCIF_IMAGE; 

    for (i=0;i<C_PAGES;i++) 
	{ 
        LoadString(hInst, IDC_TABS + i, 
                g_achTemp, sizeof(g_achTemp)/sizeof(g_achTemp[0])); 
		tie.pszText = szTabName[i]; 
		tie.iImage = i;
        if(TabCtrl_InsertItem(pHdr->hwndTab, i, &tie)== -1) 
		{ 
            DestroyWindow(pHdr->hwndTab); 
            return NULL; 
		}
	} 

    // Lock the resources for the three child dialog boxes. 
	pHdr->apRes[0] = DoLockDlgRes(MAKEINTRESOURCE(DLG_GENERAL));
    pHdr->apRes[1] = DoLockDlgRes(MAKEINTRESOURCE(DLG_STYLES));
	pHdr->apRes[2] = DoLockDlgRes(MAKEINTRESOURCE(DLG_MORESTYLES));	
	pHdr->apRes[3] = DoLockDlgRes(MAKEINTRESOURCE(DLG_EXSTYLES));
	pHdr->apRes[4] = DoLockDlgRes(MAKEINTRESOURCE(DLG_MOREEXSTYLES));
	// Calculate the display rectangle. 
    CopyRect(&pHdr->rcDisplay, &rcTab); 

	// Simulate selection of the first item. 
    OnSelChanged(hwndDlg); 

    return pHdr->hwndTab; 
} 

// DoLockDlgRes - loads and locks a dialog template resource. 
// Returns a pointer to the locked resource. 
// lpszResName - name of the resource  
DLGTEMPLATE * WINAPI DoLockDlgRes(LPCSTR lpszResName) 
{ 
    HRSRC hrsrc = FindResource(NULL, lpszResName, RT_DIALOG); 
    HGLOBAL hglb = LoadResource(hInst, hrsrc); 

    return (DLGTEMPLATE *) LockResource(hglb); 
} 

// OnSelChanged - processes the TCN_SELCHANGE notification. 
// hwndDlg - handle to the parent dialog box. 
HWND WINAPI OnSelChanged(HWND hwndDlg) 
{ 
    DLGHDR *pHdr = (DLGHDR *) GetWindowLong(hwndDlg, GWL_USERDATA);
    int iSel = TabCtrl_GetCurSel(pHdr->hwndTab); 
 
    // Destroy the current child dial!og box, if any. 
    if (pHdr->hwndDisplay != NULL) 
        DestroyWindow(pHdr->hwndDisplay); 
 
    // Create the new child dialog box. 
	pHdr->hwndDisplay = CreateDialogIndirect(hInst, 
        pHdr->apRes[iSel], hwndDlg,(DLGPROC) ChildDialogProc);
	return(pHdr->hwndDisplay);
} 
 
// OnChildDialogInit - Positions the child dialog box to fall 
//     within the display area of the tab control. 
 VOID WINAPI OnChildDialogInit(HWND hwndDlg) 
{ 
    HWND hwndParent = GetParent(hwndDlg); 
    DLGHDR *pHdr = (DLGHDR *) GetWindowLong( 
        hwndParent, GWL_USERDATA); 
    SetWindowPos(hwndDlg, HWND_TOP, 
		pHdr->rcDisplay.left, 
		pHdr->rcDisplay.top, 
		pHdr->rcDisplay.right-pHdr->rcDisplay.left, 
		pHdr->rcDisplay.bottom-pHdr->rcDisplay.top, 
		SWP_DRAWFRAME); 
}

LRESULT CALLBACK ChildDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UINT wmId, wmEvent;
	//PAINTSTRUCT ps;
	//HDC hdc;
	switch (message)
	{
	case WM_INITDIALOG:
		OnChildDialogInit(hDlg);
		UpdateFlags(TRUE);
		BACKdwID=dwID;
		BACKdwStyle=dwStyle;
		BACKdwExtendedStyle=dwExtendedStyle;
		SetDlgItemInt(hDlg,IDC_ID,dwID,FALSE);
		DoUpdateCaption=FALSE;
		SetDlgItemText(hDlg,IDC_CAPTION,szTitle);
		DoUpdateCaption=TRUE;
		SendDlgItemMessage(hDlg,IDC_STYLES,
						   CB_ADDSTRING, 
							0, (LPARAM)szStyles[0]);
		SendDlgItemMessage(hDlg,IDC_STYLES,
						   CB_ADDSTRING, 
							0, (LPARAM)szStyles[1]);
		SendDlgItemMessage(hDlg,IDC_STYLES,
						   CB_ADDSTRING, 
							0, (LPARAM)szStyles[2]);
		//----------------------------------------------
		SendDlgItemMessage(hDlg,IDC_BORDER,
						   CB_ADDSTRING, 
							0, (LPARAM)szBorders[0]);
		SendDlgItemMessage(hDlg,IDC_BORDER,
						   CB_ADDSTRING, 
							0, (LPARAM)szBorders[1]);
		SendDlgItemMessage(hDlg,IDC_BORDER,
						   CB_ADDSTRING, 
							0, (LPARAM)szBorders[2]);
		SendDlgItemMessage(hDlg,IDC_BORDER,
						   CB_ADDSTRING, 
							0, (LPARAM)szBorders[3]);
		//----------------------------------------------
		//------------------- General ------------------
		if(Visible) CheckDlgButton(hDlg,IDC_VISIBLE,TRUE);
		if(Disabled)CheckDlgButton(hDlg,IDC_DISABLED,TRUE);
		if(Group)	CheckDlgButton(hDlg,IDC_GROUP,TRUE);
		if(TabStop)	CheckDlgButton(hDlg,IDC_TABSTOP,TRUE);
		//----------------------------------------------
		//------------------- Styles -------------------
		//&Styles:Overlapped, Popup, Child
		if(OverlappedStyle)
		{
			SendDlgItemMessage(hDlg,IDC_STYLES,
								WM_SETTEXT, 
								0, (LPARAM)szStyles[0]);
		}else
		if(PopupStyle)
		{
			SendDlgItemMessage(hDlg,IDC_STYLES,
								WM_SETTEXT, 
								0, (LPARAM)szStyles[1]);
		}else
		if(ChildStyle)
		{
			SendDlgItemMessage(hDlg,IDC_STYLES,
								WM_SETTEXT, 
								0, (LPARAM)szStyles[2]);
		}
		//----------------------------------------------
		//&Border: None, Thin, Resizing, Dialog Frame
		if(NoneBorder)
		{
				SendDlgItemMessage(hDlg,IDC_BORDER,
						   WM_SETTEXT, 
							0, (LPARAM)szBorders[0]);
		}else
		if(ThinBorder)
		{
				SendDlgItemMessage(hDlg,IDC_BORDER,
						   WM_SETTEXT, 
							0, (LPARAM)szBorders[1]);
		}else
		if(ResizingBorder)
		{
				SendDlgItemMessage(hDlg,IDC_BORDER,
						   WM_SETTEXT, 
							0, (LPARAM)szBorders[2]);
		}else
		if(DialogFrameBorder)
		{
				SendDlgItemMessage(hDlg,IDC_BORDER,
						   WM_SETTEXT, 
							0, (LPARAM)szBorders[3]);
		}
		//----------------------------------------------
		if(TitleBar)	CheckDlgButton(hDlg,IDC_TITLEBAR,TRUE);
		if(SystemMenu)	CheckDlgButton(hDlg,IDC_SYSTEMMENU,TRUE);
		if(MinimizeBox)	CheckDlgButton(hDlg,IDC_MINBOX,TRUE);
		if(MaximizeBox)	CheckDlgButton(hDlg,IDC_MAXBOX,TRUE);
		if(ClipSiblings)CheckDlgButton(hDlg,IDC_CLIPSIBLING,TRUE);
		if(ClipChildren)CheckDlgButton(hDlg,IDC_CLIPCHILDREN,TRUE);
		if(HorizontalScroll)CheckDlgButton(hDlg,IDC_HORSCROLL,TRUE);
		if(VerticalScroll)CheckDlgButton(hDlg,IDC_VERSCROLL,TRUE);
		//----------------------------------------------
		//----------------- More Styles ----------------

		//----------------------------------------------
		//--------------- Extended Styles --------------
		if(ToolWindow)	CheckDlgButton(hDlg,IDC_TOOLWINDOW,TRUE);
		if(ClientEdge)	CheckDlgButton(hDlg,IDC_CLIENTEDGE,TRUE);
		if(StaticEdge)	CheckDlgButton(hDlg,IDC_STATICADGE,TRUE);
		if(Transparent)	CheckDlgButton(hDlg,IDC_TRANSPARENT,TRUE);
		if(AcceptFiles)	CheckDlgButton(hDlg,IDC_ACCEPTFILES,TRUE);
		if(ControlParent)CheckDlgButton(hDlg,IDC_CONTROLPARENT,TRUE);
		if(ContextHelp)	CheckDlgButton(hDlg,IDC_CONTEXTHELP,TRUE);
		if(NoParentNotify)CheckDlgButton(hDlg,IDC_NOPARENTNOTIFY,TRUE);
		if(RightReadingOrder)CheckDlgButton(hDlg,IDC_RIGHTREADING,TRUE);
		if(RightAligned)CheckDlgButton(hDlg,IDC_RIGHTALIGNED,TRUE);
		if(LeftScrollBar)CheckDlgButton(hDlg,IDC_LEFTSCROLL,TRUE);
		//----------------------------------------------
		//------------- More Extended Styles -----------
		if(RightLayout)	CheckDlgButton(hDlg,IDC_RIGHTLAYOUT,TRUE);
		if(NoLayoutInherit)CheckDlgButton(hDlg,IDC_NOLAYOUTINHERIT,TRUE);
		if(NoActivate)	CheckDlgButton(hDlg,IDC_NOACTIVATE,TRUE);
		if(AppWindow)	CheckDlgButton(hDlg,IDC_APPWINDOW,TRUE);
		if(DialogModalFrame)CheckDlgButton(hDlg,IDC_DLGMODALFRAME,TRUE);
		if(WindowEdge)	CheckDlgButton(hDlg,IDC_WINEDGE,TRUE);
		if(TopMost)		CheckDlgButton(hDlg,IDC_TOPMOST,TRUE);
		//----------------------------------------------
		return TRUE;
	case WM_NOTIFY:
		//Beep(100,100);
		break;

	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDC_ID:
			break;

		//----------------------------------------------
		//------------------- General ------------------
		case IDC_CAPTION:
			switch(wmEvent)
			{
			case EN_CHANGE:
				if(szTitle==0)break;
				iTitle = (WORD) SendDlgItemMessage(hDlg, 
							IDC_CAPTION, 
							EM_LINELENGTH, 
							(WPARAM) 0, 
							(LPARAM) 0); 
				*((LPWORD)szTitle) = iTitle; 
				SendDlgItemMessage(hDlg, 
						    IDC_CAPTION, 
							EM_GETLINE, 
							(WPARAM) 0,       // line 0 
							(LPARAM)szTitle);
				szTitle[iTitle] = 0; 
				if(DoUpdateCaption)
				{
					char* _szClassName=new TCHAR[strlen(szClassName)+1];
					strcpy(_szClassName,szClassName);
					CharUpperBuff(_szClassName,(DWORD)strlen(_szClassName));
					if((strstr(_szClassName,"EDIT")==NULL)&&(strstr(_szClassName,"BOX")==NULL))
					{
						SetWindowText(hHandle,szTitle);
					}
					else
					{
						HWND hWndParent=GetParent(hHandle);
						SendDlgItemMessage(hWndParent,dwID,
							   WM_SETTEXT, 
								0, (LPARAM)szTitle);
					}
					UpdateFlags(FALSE);
				}
				break;
			}
			break;
		case IDC_VISIBLE:
			Visible=!Visible;
			UpdateFlags(FALSE);
			break;

		case IDC_DISABLED:
			Disabled=!Disabled;
			UpdateFlags(FALSE);
			break;

		case IDC_GROUP:
			Group=!Group;
			UpdateFlags(FALSE);
			break;

		case IDC_TABSTOP:
			TabStop=!TabStop;
			UpdateFlags(FALSE);
			break;
		//----------------------------------------------
		//------------------- Styles -------------------
		case IDC_STYLES:
			switch(wmEvent)
			{
			case CBN_SELCHANGE:
				int iSItem=(int)SendDlgItemMessage(hDlg,IDC_STYLES,
						   CB_GETCURSEL, 
							0, 0);
				switch(iSItem)
				{
				case 0:
					OverlappedStyle=FALSE;
					PopupStyle=FALSE;
					ChildStyle=TRUE;
					break;
				case 1:
					OverlappedStyle=TRUE;
					PopupStyle=FALSE;
					ChildStyle=FALSE;
					break;
				case 2:
					OverlappedStyle=FALSE;
					PopupStyle=TRUE;
					ChildStyle=FALSE;
					break;
				}
				UpdateFlags(FALSE);
			}
			break;

		case IDC_BORDER:
			switch(wmEvent)
			{
			case CBN_SELCHANGE:
				int iBItem=(int)SendDlgItemMessage(hDlg,IDC_BORDER,
						   CB_GETCURSEL, 
							0, 0);
				switch(iBItem)
				{
				case 0:
					NoneBorder=FALSE;
					ThinBorder=FALSE;	
					ResizingBorder=FALSE;	
					DialogFrameBorder=TRUE;
					break;
				case 1:
					NoneBorder=TRUE;
					ThinBorder=FALSE;	
					ResizingBorder=FALSE;	
					DialogFrameBorder=FALSE;
					break;
				case 2:
					NoneBorder=FALSE;
					ThinBorder=FALSE;	
					ResizingBorder=TRUE;	
					DialogFrameBorder=FALSE;
					break;
				case 3:
					NoneBorder=FALSE;
					ThinBorder=TRUE;	
					ResizingBorder=FALSE;	
					DialogFrameBorder=FALSE;
					break;
				}
				UpdateFlags(FALSE);
			}
			break;
		//&Styles:Overlapped, Popup, Child
		/*if(OverlappedStyle;	
		if(PopupStyle;		
		if(ChildStyle;		*/
		//----------------------------------------------
		//&Border: None, Thin, Resizing, Dialog Frame
		/*if(NoneBorder;
		if(ThinBorder;		
		if(ResizingBorder;	
		if(DialogFrameBorder;	*/
		//----------------------------------------------
		case IDC_TITLEBAR:
			TitleBar=!TitleBar;
			UpdateFlags(FALSE);
			break;

		case IDC_SYSTEMMENU:
			SystemMenu=!SystemMenu;
			UpdateFlags(FALSE);
			break;

		case IDC_MINBOX:
			MinimizeBox=!MinimizeBox;
			UpdateFlags(FALSE);
			break;

		case IDC_MAXBOX:
			MaximizeBox=!MaximizeBox;
			UpdateFlags(FALSE);
			break;

		case IDC_CLIPSIBLING:
			ClipSiblings=!ClipSiblings;
			UpdateFlags(FALSE);
			break;

		case IDC_CLIPCHILDREN:;
			ClipChildren=!ClipChildren;
			UpdateFlags(FALSE);
			break;

		case IDC_HORSCROLL:
			HorizontalScroll=!HorizontalScroll;
			UpdateFlags(FALSE);
			break;

		case IDC_VERSCROLL:
			VerticalScroll=!VerticalScroll;
			UpdateFlags(FALSE);
			break;
		//----------------------------------------------
		//----------------- More Styles ----------------

		//----------------------------------------------
		//--------------- Extended Styles --------------
		case IDC_TOOLWINDOW:
			ToolWindow=!ToolWindow;
			UpdateFlags(FALSE);
			break;

		case IDC_CLIENTEDGE:
			ClientEdge=!ClientEdge;
			UpdateFlags(FALSE);
			break;

		case IDC_STATICADGE:
			StaticEdge=!StaticEdge;
			UpdateFlags(FALSE);
			break;

		case IDC_TRANSPARENT:
			Transparent=!Transparent;
			UpdateFlags(FALSE);
			break;

		case IDC_ACCEPTFILES:
			AcceptFiles=!AcceptFiles;
			UpdateFlags(FALSE);
			break;

		case IDC_CONTROLPARENT:
			ControlParent=!ControlParent;
			UpdateFlags(FALSE);
			break;

		case IDC_CONTEXTHELP:
			ContextHelp=!ContextHelp;
			UpdateFlags(FALSE);
			break;

		case IDC_NOPARENTNOTIFY:
			NoParentNotify=!NoParentNotify;
			UpdateFlags(FALSE);
			break;

		case IDC_RIGHTREADING:
			RightReadingOrder=!RightReadingOrder;
			UpdateFlags(FALSE);
			break;

		case IDC_RIGHTALIGNED:
			RightAligned=!RightAligned;
			UpdateFlags(FALSE);
			break;

		case IDC_LEFTSCROLL:
			LeftScrollBar=!LeftScrollBar;
			UpdateFlags(FALSE);
			break;
		//----------------------------------------------
		//------------- More Extended Styles -----------
		case IDC_RIGHTLAYOUT:
			RightLayout=!RightLayout;
			UpdateFlags(FALSE);
			break;

		case IDC_NOLAYOUTINHERIT:
			NoLayoutInherit=!NoLayoutInherit;
			UpdateFlags(FALSE);
			break;

		case IDC_NOACTIVATE:
			NoActivate=!NoActivate;
			UpdateFlags(FALSE);
			break;

		case IDC_APPWINDOW:
			AppWindow=!AppWindow;
			UpdateFlags(FALSE);
			break;

		case IDC_DLGMODALFRAME:
			DialogModalFrame=!DialogModalFrame;
			UpdateFlags(FALSE);
			break;

		case IDC_WINEDGE:
			WindowEdge=!WindowEdge;
			UpdateFlags(FALSE);
			break;

		case IDC_TOPMOST:
			TopMost=!TopMost;
			UpdateFlags(FALSE);
			break;
		}
		break;

	}
	return FALSE;
}
