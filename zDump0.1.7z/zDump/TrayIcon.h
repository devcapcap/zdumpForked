/* TrayIcon.h --

   This file is part of the "zero Dump 0.1".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   zero Dump library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#pragma once

#define	ID_TRAYICON						1000
#define	IDT_FIRST						1001
#define	IDT_RESTORE						IDT_FIRST + 1
#define	IDT_EXIT						IDT_FIRST + 2
#define	IDT_SEPARATOR					IDT_FIRST + 3
#define	WM_TRAYMENU						WM_USER + IDT_FIRST

void CreateTrayIcon();

void TrayIconWM_TRAYMENU(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL TrayIconWM_COMMAND(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void TrayIconWM_SIZE(HWND hWnd, WPARAM wParam, LPARAM lParam);