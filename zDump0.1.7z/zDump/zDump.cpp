/* zDump.cpp --

   This file is part of the "zero Dump 0.1".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   zero Dump library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
//#define  WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include "zDump.h"
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <winuser.h>
#include "TrayIcon.h"
#include "TabCtrl.h"
#include "DumpSeek.h"
#include "DumpWin.h"

#pragma comment(linker,"/BASE:0x400000 /FILEALIGN:0x200 /MERGE:.rdata=.text /MERGE:.data=.text /SECTION:.text,EWR /IGNORE:4078")
#pragma pack(1)

// Global Variables:

HINSTANCE hInst;	// current instance

char g_achTemp[256];// temporary buffer for strings 

HDROP	hDrop;
HICON	hIcon;
HBITMAP	hBitmap;
HWND	hButton;

HWND	hSeekedWindow;
BOOL	bSeeking;
HCURSOR	hSeekingCursor;
static	POINTS points;
HICON	hIconDown;
HICON	hIconUp;
HWND	hSeekerIcon;
HDC		hDCSeekerIcon;

RECT	rcClip;			// new area for ClipCursor
RECT	rcOldClip;		// previous area for ClipCursor


HWND	hwndMain;		// main application window 
HMENU	hMenu;

HACCEL	hAccel;
HWND	hDesktopHandle;
char	szSeekedWindow[12];
bool	bStayOnTop=TRUE;

// Forward declarations of functions included in this code module:
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Properties(HWND, UINT, WPARAM, LPARAM);

LRESULT DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	hInst=GetModuleHandle(0);

	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_MAINDLG),0,(DLGPROC)DlgProc,0);
	//DoPropertySheet(hInst);
	ExitProcess(0);
	return (int) msg.wParam;
}

void SetWindowTop(HWND hWnd,bool Value)
{
	if(Value)
	{
         SetWindowPos(hWnd, 
            HWND_TOPMOST, 
            0, 0, 0, 0,
            SWP_NOSIZE|SWP_NOMOVE|SWP_SHOWWINDOW);
	}
	else
	{
         SetWindowPos(hWnd, 
            HWND_NOTOPMOST, 
            0, 0, 0, 0,
            SWP_NOSIZE|SWP_NOMOVE|SWP_SHOWWINDOW); 
	}
}
// internal helpers
// 
static void FrameWindow(HWND hWnd)
{
	if (!IsWindow(hWnd)) return;

	RECT wndRect;
	GetWindowRect(hWnd,&wndRect);
	//   wndRect.NormalizeRect();
	SetRect(&wndRect,0,0,
		wndRect.right - wndRect.left,
		wndRect.bottom - wndRect.top);

	HDC      hDC;
	int      iOldROP;
	HPEN     hPen;
	HPEN     hOldPen;
	HBRUSH   hOldBrush;

	hDC = GetWindowDC(hWnd);
	iOldROP = SetROP2(hDC, R2_XORPEN);
	hPen = CreatePen(PS_SOLID, GetSystemMetrics(SM_CXSIZEFRAME), RGB(255, 255, 255));
	hOldPen = (HPEN)SelectObject(hDC, hPen);
	hOldBrush = (HBRUSH)SelectObject(hDC, GetStockObject(NULL_BRUSH));

	Rectangle(hDC, wndRect.left, wndRect.top, wndRect.right, wndRect.bottom);
   
	SelectObject(hDC, hOldBrush);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
	SetROP2(hDC, iOldROP);
	ReleaseDC(hWnd, hDC);
}

//  FUNCTION: DlgProc(HWND, unsigned, WORD, LONG)
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
LRESULT DlgProc(HWND hDlg,UINT uiMsg,WPARAM wParam,LPARAM lParam)
{
	UINT wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	POINT point;
	switch (uiMsg) 
	{
	case WM_INITDIALOG:
		hwndMain=hDlg;

		LoadFromRegistry(&bStayOnTop);
		SetWindowTop(hDlg,bStayOnTop);
		CheckDlgButton(hDlg,IDC_STAYONTOP,bStayOnTop);

		hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON));
		SendMessage(hDlg,WM_SETICON,TRUE,(WPARAM)hIcon);
	
		hAccel=LoadAccelerators(hInst,MAKEINTRESOURCE(IDC_ZDUMP));
		hSeekingCursor=LoadCursor(hInst,MAKEINTRESOURCE(IDC_FINDER));

		hIconDown=LoadIcon(hInst,MAKEINTRESOURCE(IDI_FLOATINGFINDER));
		hIconUp=LoadIcon(hInst,MAKEINTRESOURCE(IDI_DOCKEDFINDER));
		hSeekerIcon=GetDlgItem(hDlg,IDC_STATIC_SEEKER);
		hDCSeekerIcon=GetWindowDC(hSeekerIcon);

		CreateTrayIcon();
		
		//SendMessage(hDlg,WM_SETCURSOR,(WPARAM)hCursor,0);


		//SetCursor(hCursor);
		//ShowCursor(TRUE);
		/*hDesktopHandle=GetDesktopWindow();
		//if (IsIconic(hDlg)) 
		//{ 
			//SetCursor(hCursor); 
		//}
		// Record the area in which the cursor can move. 
		GetClipCursor(&rcOldClip); 
		// Get the dimensions of the application's window. 
		GetWindowRect(hDesktopHandle, &rcClip); 
		// Confine the cursor to the application's window. 
		ClipCursor(&rcClip); 
		// 
		// Process input from the confined cursor. 
		// 
		SetCursor(hCursor);
		/*SetClassLong(hDlg,    // window handle 
			GCL_HCURSOR,      // change cursor 
			(LONG) hCursor);   // new cursor */
		// Restore the cursor to its previous area. 
 
		//ClipCursor(&rcOldClip); */

		break;   

	/*case WM_DROPFILES:
		hDrop=HDROP(wParam);
		DragQueryFile(hDrop,0,cFnameOpen,sizeof(cFnameOpen));
		DragFinish(hDrop);
		SetDlgItemText(hwndDisplay,IDC_FILE_OPEN,cFnameOpen);
		break;*/
 	   
	case WM_COMMAND:
		TrayIconWM_COMMAND(hDlg, uiMsg, wParam, lParam);
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{

		case IDCLOSE:
			SendMessage(hDlg,WM_CLOSE,NULL,NULL);
			break;
              	                  
		case IDOK:
			EndDialog(hDlg,0);
			break;

		case ID_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hDlg, (DLGPROC)About);
			break;

		case IDC_SETPROPRT:
			hHandle=hSeekedWindow;
			if(IsWindow(hSeekedWindow))
			{
				DialogBox(hInst, (LPCTSTR)IDD_PROPRT, hDlg, (DLGPROC)Properties);
				GetWindowInfo(hSeekedWindow);
			}
			break;
		case IDC_STAYONTOP:
			bStayOnTop=!bStayOnTop;
			SaveToRegistry(bStayOnTop);
			SetWindowTop(hDlg,bStayOnTop);
			break;
		case IDC_OPTION:
			MessageBox(GetActiveWindow(),"Sorry! This part is not compelet yet.","Not Now ;)",MB_ICONINFORMATION);
			break;
		case IDC_SENDMSG:
			MessageBox(GetActiveWindow(),"Sorry! This part is not compelet yet.","Not Now ;)",MB_ICONINFORMATION);
			break;
		}
		break;

	case WM_LBUTTONDOWN:
			// default processing
			points = MAKEPOINTS(lParam); 
			point.x=points.x;
			point.y=points.y;
			// change the cursor
			SetCursor(hSeekingCursor);
			// change the icon itself
			//SetIcon(hIconDown);
			DrawIcon(hDCSeekerIcon, 0, 0, hIconDown); 
			// start seeking
			bSeeking = TRUE;
			hSeekedWindow = hDlg;
			FrameWindow(hSeekedWindow);
			SetCapture(hDlg);

		break;

	case WM_LBUTTONUP:
		if (bSeeking)
		{
			// end seeking
			bSeeking = FALSE;
			FrameWindow(hSeekedWindow);
			ReleaseCapture();
			// Restore the Finder Tool icon
			//SetIcon(hIconUp);
			DrawIcon(hDCSeekerIcon, 0, 0, hIconUp); 
		}
		points = MAKEPOINTS(lParam); 
		point.x=points.x;
		point.y=points.y;
		break;

	case WM_MOUSEMOVE:
		if (bSeeking)
		{
			// !!! if you change the cursor, you change the icon !!!
			// change the cursor
			// SetCursor(m_hSeekingCursor);
   			// see if there is a different window under the mouse
			HWND hWindowUnderTheMouse;
			//HWND hWindowUnderTheMouseChild;
			points = MAKEPOINTS(lParam); 
			point.x=points.x;
			point.y=points.y;
			ClientToScreen(hDlg,&point);
			hWindowUnderTheMouse = WindowFromPoint(point);
			/*hWindowParent1 = ::WindowFromPoint(point);
			//hWindowParent2 = ::GetAncestor(hWindowParent1,GA_ROOTOWNER);*/
			//hChildFound=GetWindow(hWindowUnderTheMouse, GW_HWNDLAST);
			//ChildWindowFromPointEx(hWindowUnderTheMouse,point,CWP_ALL);
			//if(hWindowUnderTheMouse==NULL) hWindowUnderTheMouse=hWindowParent1;
			/*HWND hParentWnd,hChildWnd;
			hChildWnd=hWindowUnderTheMouse;
			hParentWnd=GetParent(hWindowUnderTheMouse);
			hChildFound=NULL;
			if(hParentWnd!=0)
			{
				while(IsWindow(hChildWnd))
				{
					hChildFound=hChildWnd;
					hChildWnd=ChildWindowFromPointEx(hParentWnd,point,CWP_ALL);
					if(hChildWnd==hParentWnd)break;
					if(hChildWnd==NULL)break;
					hParentWnd=hChildWnd;
				}
				
			}*/
			if((hwndMain==hWindowUnderTheMouse)||
			   (hwndMain==GetParent(hWindowUnderTheMouse)))
			{
				break;
			}
			//------------------------------
			hChildFound=NULL;
			SeekDumpWindow(hWindowUnderTheMouse,point);
			if((IsWindow(hChildFound))&&(hChildFound!=NULL))
			{
				hWindowUnderTheMouse=hChildFound;
			}
			//------------------------------
			if(hWindowUnderTheMouse != hSeekedWindow)
			{
				//
				FrameWindow(hSeekedWindow);
				hSeekedWindow = hWindowUnderTheMouse;
				FrameWindow(hSeekedWindow);

				// update the twin window
				strcpy(szSeekedWindow,"0x");
				_itoa((DWORD)hSeekedWindow,szSeekedWindow+2,16);
				CharUpperBuff(szSeekedWindow+2,(DWORD)strlen(szSeekedWindow));
				SetDlgItemText(hDlg,IDC_WINDOWHANDLE,szSeekedWindow);
				GetWindowInfo(hSeekedWindow);
			}
		}
		else
		{
			points = MAKEPOINTS(lParam); 
			point.x=points.x;
			point.y=points.y;
		}
		break;


	case WM_PAINT:
		hdc = BeginPaint(hDlg, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hDlg, &ps);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	case WM_CLOSE:
		EndDialog(hDlg,0);
		break;
	case WM_SIZE:
		TrayIconWM_SIZE(hDlg, wParam, lParam);
		break;
	case WM_TRAYMENU:
		TrayIconWM_TRAYMENU(hDlg, uiMsg, wParam, lParam);
		return 0;
	}
	return 0;
}

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UINT wmId, wmEvent;
	switch (message)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
			break;
		case IDC_WEB:
			WinExec("Explorer http://yodap.has.it/", SW_SHOWMAXIMIZED);
			break;
		}
		break;
	}
	return FALSE;
}

HWND	hwndTab;	// tab control 
HWND	hwndDisplay;// handle to static control in 
					//   tab control's display area 
// Global variables 

int		iPage;
int		iPageOld=0;

LRESULT CALLBACK Properties(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UINT wmId, wmEvent;
	switch (message)
	{
	case WM_INITDIALOG:
		hwndTab=OnTabbedDialogInit(hDlg);
		return TRUE;

	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
			break;
		case IDC_WEB:
			WinExec("Explorer http://yodap.has.it/", SW_SHOWMAXIMIZED);
			break;
		}
		break;

	case WM_NOTIFY: 
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam);
		wmEvent=TCN_SELCHANGE;
		switch (wmEvent) 
		{ 
		case 0: 
			// menu command processing 
		case TCN_SELCHANGE: 
			iPage= TabCtrl_GetCurSel(hwndTab); 
			if(iPage!=iPageOld)
			{
				LoadString(hInst,IDC_TABS + iPage, 
						g_achTemp,
						sizeof(g_achTemp)/sizeof(g_achTemp[0])); 
				hwndDisplay=OnSelChanged(hDlg);
				SendMessage(hwndDisplay, WM_SETTEXT, 0,
						(LPARAM) g_achTemp);
				switch(iPage)
				{
				case 0:
					break;
				case 1:
					break;
				case 3:
					break;
				}
			}
			iPageOld=iPage;
			break; 
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
			case IDOK:
				Beep(100,100);
				break;
			}
		} 
		break; 
	}
	return FALSE;
}
