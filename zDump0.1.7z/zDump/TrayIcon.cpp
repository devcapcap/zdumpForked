/* TrayIcon.cpp --

   This file is part of the "zero Dump 0.1".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   zero Dump library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include "zDump.h"
#include <shellapi.h>
#include "TrayIcon.h"

#ifdef _DEBUG
#define DEBUG_NEW
#endif

void ToTop();
void Quit();
BOOL KillTrayIcon();
BOOL ToTray();
BOOL ReturnFromTray();

void CreateTrayIcon();

void TrayIconWM_TRAYMENU(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL TrayIconWM_COMMAND(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void TrayIconWM_SIZE(HWND hWnd, WPARAM wParam, LPARAM lParam);


RECT			rctLastPos;
NOTIFYICONDATA	nidTray;
HMENU			hmTray;

void ToTop()
{
	SetForegroundWindow(hwndMain);
	return;
}

void Quit()
{
	SendMessage(hwndMain, WM_CLOSE, 0, 0);
	return;
}

BOOL KillTrayIcon()
{
	return Shell_NotifyIcon(NIM_DELETE, &nidTray);
}

//
// install tray icon + hide main win
//
BOOL ToTray()
{
	HICON hTrayIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON));
	// add tray icon
	memset(&nidTray, 0, sizeof(nidTray));
	// build tip
	nidTray.cbSize            = sizeof(nidTray);

	int iTip= GetWindowTextLength(hwndMain);
	GetWindowText(hwndMain,nidTray.szTip,iTip+1);

	nidTray.hWnd              = hwndMain;
	nidTray.uID               = ID_TRAYICON;
	nidTray.uFlags            = NIF_TIP | NIF_ICON | NIF_MESSAGE;
	nidTray.hIcon             = hTrayIcon;//(HICON)GetClassLong(hwndMain, GCL_HICON);
	nidTray.uCallbackMessage  = WM_TRAYMENU;
	if (!Shell_NotifyIcon(NIM_ADD, &nidTray)) return FALSE; //ERR
	// hide win
	ShowWindow(hwndMain, SW_HIDE);
	return TRUE; // OK
}

BOOL ReturnFromTray()
{
	// kill tray icon
	if (!KillTrayIcon())
		return FALSE; // ERR

	// show win
	ShowWindow(hwndMain, SW_RESTORE);
	ToTop();

	return TRUE; // OK
}

void CreateTrayIcon()
{
	hmTray = CreatePopupMenu();
	AppendMenu(hmTray, MF_STRING, ID_ABOUT, "About...");
	AppendMenu(hmTray, MF_STRING, IDT_RESTORE, "Restore zDump");
	AppendMenu(hmTray, MF_SEPARATOR, IDT_SEPARATOR,"");
	AppendMenu(hmTray, MF_STRING, IDT_EXIT, "Quit zDump");
}


void TrayIconWM_TRAYMENU(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	POINT p;
	switch(lParam)
	{
	case WM_RBUTTONDOWN:
		GetCursorPos(&p);
		TrackPopupMenu(hmTray, TPM_RIGHTALIGN, p.x, p.y, 0, hWnd, NULL);
		break;

	case WM_LBUTTONDBLCLK:
		ReturnFromTray();
		break;
	}
	return;
}

//extern const char*  szFormCaption;
BOOL TrayIconWM_COMMAND(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(LOWORD(wParam))
	{
	case IDT_RESTORE:
		ReturnFromTray();
		return TRUE;

	case IDT_EXIT:
		KillTrayIcon();
		Quit();
		return TRUE;
	}
	return FALSE; // ERR
}

void TrayIconWM_SIZE(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	// save pos
	if ( wParam != SIZE_MINIMIZED &&
		 wParam != SIZE_MAXIMIZED)
		 GetWindowRect( hWnd, &rctLastPos );
	if (wParam == SIZE_MINIMIZED)
	{
		ToTray();
		return;
	}
}
//